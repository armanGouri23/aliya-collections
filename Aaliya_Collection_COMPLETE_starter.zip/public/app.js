let products=[],cart=JSON.parse(localStorage.getItem('aaliyaCart')||'[]'),category='All';
const money=n=>'₹'+Number(n).toLocaleString('en-IN');
async function load(){try{products=await(await fetch('/api/products')).json()}catch{products=[]}render();count()}
function filter(c){category=c;render()}
function render(){let q=(document.getElementById('search')?.value||'').toLowerCase();let list=products.filter(p=>(category==='All'||p.category===category)&&p.name.toLowerCase().includes(q));document.getElementById('products').innerHTML=list.length?list.map(p=>`<article class="product"><div class="photo">${p.image?`<img src="${esc(p.image)}" alt="">`:'✧'}</div><small>${esc(p.category)}</small><h3>${esc(p.name)}</h3><div class="price">${money(p.price)}</div><button onclick="add(${p.id})">Add to bag</button></article>`).join(''):'<p>Products are being added soon. Check back shortly ✨</p>'}
function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function add(id){let x=cart.find(a=>a.id===id);x?x.qty++:cart.push({id,qty:1});save();showCart()}
function save(){localStorage.setItem('aaliyaCart',JSON.stringify(cart));count()}
function count(){document.getElementById('count').textContent=cart.reduce((a,b)=>a+b.qty,0)}
function showCart(){document.getElementById('modal').classList.add('open');cartUI()}
function closeCart(){document.getElementById('modal').classList.remove('open')}
function cartUI(){let html=cart.map(x=>{let p=products.find(p=>p.id===x.id);return p?`<p>${esc(p.name)} × ${x.qty} — ${money(p.price*x.qty)} <button onclick="removeItem(${x.id})">Remove</button></p>`:''}).join('');document.getElementById('cartitems').innerHTML=html||'Bag is empty';document.getElementById('total').textContent='Total: '+money(cart.reduce((s,x)=>s+((products.find(p=>p.id===x.id)?.price)||0)*x.qty,0))}
function removeItem(id){cart=cart.filter(x=>x.id!==id);save();cartUI()}
async function checkout(){let msg=document.getElementById('checkoutmsg');if(!cart.length)return msg.textContent='Add products first.';if(document.getElementById('pay').value!=='COD')return msg.textContent='Online UPI gateway is not active. Please choose COD.';let body={name:custname.value,phone:custphone.value,address:custaddress.value,payment:'COD',items:cart};try{let r=await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body}),d=await r.json();if(!r.ok)throw Error(d.error);msg.textContent=`Order placed! ID: ${d.orderCode} · Total ${money(d.total)}`;cart=[];save();cartUI()}catch(e){msg.textContent=e.message}}
async function trackOrder(){let r=await fetch('/api/orders/track',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:trackcode.value,phone:trackphone.value})}),d=await r.json();trackresult.textContent=r.ok?`Status: ${d.status} · ${d.code}`:d.error}
async function returnReq(){let r=await fetch('/api/returns',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({orderCode:retcode.value,phone:retphone.value,reason:retreason.value})}),d=await r.json();retmsg.textContent=r.ok?'Request received! We will contact you.':d.error}
load();
